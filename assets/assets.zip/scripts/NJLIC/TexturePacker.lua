local TexturePacker = {}
TexturePacker.__index = TexturePacker

--#############################################################################
--DO NOT EDIT ABOVE
--#############################################################################

--#############################################################################
--Begin Custom Code
--Required local functions:
--  __ctor()
--  __dtor()
--  __load()
--  __unLoad()
--#############################################################################
local function print_r ( t )
    local print_r_cache={}
    local function sub_print_r(t,indent)
        if (print_r_cache[tostring(t)]) then
            print(indent.."*"..tostring(t))
        else
            print_r_cache[tostring(t)]=true
            if (type(t)=="table") then
                for pos,val in pairs(t) do
                    if (type(val)=="table") then
                        print(indent.."["..pos.."] => "..tostring(t).." {")
                        sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
                        print(indent..string.rep(" ",string.len(pos)+6).."}")
                    elseif (type(val)=="string") then
                        print(indent.."["..pos..'] => "'..val..'"')
                    else
                        print(indent.."["..pos.."] => "..tostring(val))
                    end
                end
            else
                print(indent..tostring(t))
            end
        end
    end
    if (type(t)=="table") then
        print(tostring(t).." {")
        sub_print_r(t," ")
        print("}")
    else
        sub_print_r(t," ")
    end
    print()
end


local __ctor = function(self, init)
    local tbl = init or {}


    local tp = tbl.file or nil
    local numInstances = init.numInstances or 10000

    if tp then
        local assetPath = njlic.ASSET_PATH("scripts/generated/texturepacker/" .. tp .. ".lua")
        self._sheetInfo = loadfile(assetPath)()
        -- print_r(self._sheetInfo)
    end

    local shader = njlic.ShaderProgram.create()
    assert(njlic.World.getInstance():getWorldResourceLoader():load("shaders/StandardShader.vert", "shaders/StandardShader.frag", shader))

    local geometry = njlic.Sprite2D.create()
    geometry:load(shader, numInstances, 1)

    local image = njlic.Image.create()
    assert( njlic.World.getInstance():getWorldResourceLoader():load("images/generated/" .. tp .. ".png", image))

    local material = njlic.Material.create()
    geometry:setMaterial(material)
    geometry:getMaterial():getDiffuse():loadGPU(image)
    njlic.Image.destroy(image)

    self._sheetData = {material=material, shader=shader, geometry=geometry}

    print("TexturePacker:__ctor()", tp)

end

local __dtor = function(self)
    --TODO: destruct this Entity


    local material = self._sheetData.material or nil
    local geometry = self._sheetData.geometry or nil
    local shader = self._sheetData.shader or nil

    geometry:getMaterial():getDiffuse():unLoadGPU()

    njlic.Material.destroy(material)
    njlic.Sprite2D.destroy(geometry)
    njlic.ShaderProgram.destroy(shader)
end

local __load = function(self)
--TODO: load this Entity
end

local __unLoad = function(self)
--TODO: unload this Entity
end

--#############################################################################

function TexturePacker:has(...)
    local arg = ... or {}
    local name = arg.name or "?"
    local frameNumber = self._sheetInfo:getFrameIndex(name)
    if frameNumber then return true end
    return false
end

function TexturePacker:draw(...)
    local arg = ... or {}
    local node = arg.node or nil -- njlic.Node.create()
    local name = arg.name or "?"

    assert(node ~= nil)

    local updateDimensions = true
    if arg.updateDimensions ~= nil then
        updateDimensions = arg.updateDimensions
    end

    local frameNumber = self._sheetInfo:getFrameIndex(name)
    assert(frameNumber, "no such name in the textrue packer file as " .. name)

    local frame = self._sheetInfo.sheet.frames[frameNumber]
    local x = frame.x or 0
    local y = frame.y or 0
    local width = frame.width or 0
    local height = frame.height or 0
    local pivotx = (frame.pivotx / width) or 0
    local pivoty = (frame.pivoty / height) or 0

    local geometry = self._sheetData.geometry or nil
    assert(geometry, "there must be geometry loaded")

    geometry:setName(name)

    --node:setName(name)
    node:setGeometry(geometry)

    geometry:setSpriteAtlasFrame(node, x, y, width, height)

    if true == updateDimensions then
        geometry:setDimensions(node,
            bullet.btVector2( width, height),
            bullet.btVector2( pivotx, pivoty ))
    end

    return node, bullet.btVector2(width, height), frame

end

function TexturePacker:hide(camera)
    self._hiddenCamera=camera

    local geometry = self._sheetData.geometry or nil
    if geometry then
        geometry:hide(camera)
    end
end

function TexturePacker:show(camera)
    self._showCamera=camera

    local geometry = self._sheetData.geometry or nil
    if geometry then
        geometry:show(camera)
    end
end

--#############################################################################
--End Custom Code
--#############################################################################


--#############################################################################
--DO NOT EDIT BELOW
--#############################################################################

setmetatable(TexturePacker, {
    __call = function (cls, ...)
        local self = setmetatable({}, cls)
        self:_create(...)
        return self
    end,
})

function TexturePacker:className()
    return "TexturePacker"
end

function TexturePacker:class()
    return self
end

function TexturePacker:superClass()
    return nil
end

function TexturePacker:isa(theClass)
    local b_isa = false
    local cur_class = theClass:class()
    while ( nil ~= cur_class ) and ( false == b_isa ) do
        if cur_class == theClass then
            b_isa = true
        else
            cur_class = cur_class:superClass()
        end
    end

    return b_isa
end

function TexturePacker:__gc()
    TexturePacker._destroy(self)
end

function TexturePacker:__tostring()
    local ret = self:className() .. " =\n{\n"

    for pos,val in pairs(self) do
        ret = ret .. "\t" .. "["..pos.."]" .. " => " .. type(val) .. " = " .. tostring(val) .. "\n"
    end

    return ret .. "\n\t" .. tostring_r(getmetatable(self)) .. "\n}"
end

function TexturePacker:_destroy()
    assert(not self.__TexturePackerCalledLoad, "Must unload before you destroy")

    __dtor(self)
end

function TexturePacker:_create(init)
    self.__TexturePackerCalledLoad = false

    __ctor(self, init)
end

function TexturePacker:load()
    __load(self)

    self.__TexturePackerCalledLoad = true
end

function TexturePacker:unLoad()
    assert(self.__TexturePackerCalledLoad, "Must load before unloading")

    __unLoad(self)
    self.__TexturePackerCalledLoad = false
end

return TexturePacker
